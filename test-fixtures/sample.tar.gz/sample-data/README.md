# Test Data

This directory contains test files for libuntar.

## Files

- file1.txt - First test file
- file2.txt - Second test file
- nested/deep.txt - Nested file
